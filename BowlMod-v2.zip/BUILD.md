# Build

1. New public repo. Upload `BowlMod-v2.zip` as one file. Commit.
2. **Actions → set up a workflow yourself** → paste below → name it `build.yml`.
3. Commit, **Run workflow**, download `BowlMod-apk`.

```yaml
name: build

on:
  push:
  workflow_dispatch:

jobs:
  apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'

      - name: unpack
        shell: bash
        run: unzip -o BowlMod-v2.zip

      - name: build
        run: gradle assembleDebug --no-daemon

      - uses: actions/upload-artifact@v4
        with:
          name: BowlMod-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```
