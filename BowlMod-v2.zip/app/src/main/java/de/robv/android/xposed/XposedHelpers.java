package de.robv.android.xposed;

public final class XposedHelpers {
    public static Object findAndHookMethod(Class<?> c, String n, Object... rest) { return null; }
    public static Object findAndHookMethod(String c, ClassLoader l, String n, Object... rest) { return null; }
    public static Object callMethod(Object o, String n, Object... a) { return null; }
    public static Object getObjectField(Object o, String n) { return null; }
}
