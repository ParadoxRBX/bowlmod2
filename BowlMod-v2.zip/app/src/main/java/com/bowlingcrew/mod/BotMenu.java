package com.bowlingcrew.mod;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/**
 * In-game overlay. The decor view is empty at onResume, so offer() retries
 * until the view tree exists instead of giving up on the first attempt.
 */
public final class BotMenu {

    private static final long BEAT = 4500;
    private static final int MAX_TRIES = 20;
    private static final long TRY_MS = 250;

    /** Ball centre. */
    private static final float GRAB_Y = 0.66f;
    /** Just above the pin deck. */
    private static final float RELEASE_Y = 0.30f;
    /** Lane pocket. */
    private static final float AIM = 0.545f;
    /** Rightward entry angle. */
    private static final float ANGLE = 0.035f;

    private static BotMenu sInstance;
    private static int sTries;

    private final Activity act;
    private final FrameLayout decor;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private View target;

    boolean autoAim = true;
    boolean autoShot;
    int trim;

    private Line line;
    private View dot;
    private View panel;
    private TextView state;
    private long busyUntil;

    private BotMenu(Activity a, FrameLayout d) {
        act = a;
        decor = d;
    }

    /** Called from every lifecycle hook; safe to call repeatedly. */
    static void offer(final Activity a) {
        final BotMenu cur = sInstance;
        if (cur != null && cur.act == a && cur.dot != null) return;

        View dv;
        try {
            dv = a.getWindow().getDecorView();
        } catch (Throwable t) {
            return;
        }
        if (!(dv instanceof FrameLayout)) return;
        final FrameLayout dec = (FrameLayout) dv;

        if (dec.getChildCount() == 0) {
            if (sInstance == null || sInstance.act != a) {
                sInstance = new BotMenu(a, dec);
                sTries = 0;
            }
            if (sTries++ < MAX_TRIES) {
                sInstance.ui.postDelayed(new Runnable() {
                    public void run() {
                        offer(a);
                    }
                }, TRY_MS);
            }
            return;
        }

        sInstance = new BotMenu(a, dec);
        sInstance.install();
    }

    private void install() {
        try {
            target = decor.getChildAt(0);
            line = new Line(act, this);
            decor.addView(line, new FrameLayout.LayoutParams(-1, -1));

            dot = new View(act);
            dot.setBackgroundResource(R.drawable.fab_bg);
            dot.setAlpha(0.6f);
            FrameLayout.LayoutParams flp =
                    new FrameLayout.LayoutParams(dp(44), dp(44));
            flp.gravity = Gravity.TOP | Gravity.END;
            flp.topMargin = dp(110);
            flp.rightMargin = dp(6);
            dot.setOnTouchListener(new DotTouch());
            decor.addView(dot, flp);

            Toast.makeText(act, "mod attached", Toast.LENGTH_SHORT).show();
            ui.post(loop);
        } catch (Throwable t) {
            android.util.Log.e("BowlMod", "install failed", t);
        }
    }

    private void openPanel() {
        if (panel != null) return;

        Context c = new ContextThemeWrapper(act, R.style.PanelTheme);
        panel = LayoutInflater.from(c).inflate(R.layout.panel, null);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(260), -2);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = dp(164);
        lp.rightMargin = dp(6);

        state = panel.findViewById(R.id.txtState);
        panel.findViewById(R.id.btnClose).setOnClickListener(v -> closePanel());

        final Switch aim = panel.findViewById(R.id.swAim);
        aim.setChecked(autoAim);
        aim.setOnCheckedChangeListener((b, on) -> {
            autoAim = on;
            paint();
        });

        final Switch shot = panel.findViewById(R.id.swShot);
        shot.setChecked(autoShot);
        shot.setOnCheckedChangeListener((b, on) -> {
            autoShot = on;
            paint();
        });

        panel.findViewById(R.id.btnLeft).setOnClickListener(v -> {
            trim = Math.max(-15, Math.min(15, trim - 1));
            paint();
        });
        panel.findViewById(R.id.btnRight).setOnClickListener(v -> {
            trim = Math.max(-15, Math.min(15, trim + 1));
            paint();
        });
        panel.findViewById(R.id.btnReset).setOnClickListener(v -> {
            trim = 0;
            paint();
        });
        panel.findViewById(R.id.btnOnce).setOnClickListener(v -> fire());

        decor.addView(panel, lp);
        paint();
    }

    private void closePanel() {
        if (panel == null) return;
        decor.removeView(panel);
        panel = null;
        state = null;
    }

    private class DotTouch implements View.OnTouchListener {
        private float dy;
        private int start;
        private boolean moved;

        public boolean onTouch(View v, MotionEvent e) {
            FrameLayout.LayoutParams lp =
                    (FrameLayout.LayoutParams) v.getLayoutParams();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dy = e.getRawY();
                    start = lp.topMargin;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawY() - dy) > dp(10)) moved = true;
                    lp.topMargin = start + (int) (e.getRawY() - dy);
                    v.setLayoutParams(lp);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        if (panel == null) openPanel(); else closePanel();
                    }
                    return true;
                default:
                    return true;
            }
        }
    }

    int dp(float v) {
        return Math.round(v * act.getResources().getDisplayMetrics().density);
    }

    private int[] screen() {
        DisplayMetrics dm = new DisplayMetrics();
        act.getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        return new int[]{Math.min(dm.widthPixels, dm.heightPixels),
                Math.max(dm.widthPixels, dm.heightPixels)};
    }

    private float aimX(int w) {
        return w * (AIM + trim / 100f);
    }

    private void paint() {
        int[] s = screen();
        float x = aimX(s[0]);
        float y1 = s[1] * GRAB_Y;
        float y2 = s[1] * RELEASE_Y;
        if (line != null) {
            line.show(x, y1, x + s[0] * ANGLE, y2, autoAim || autoShot);
        }
        if (state != null) {
            state.setText("aim " + Math.round(x * 100f / s[0]) + "%");
        }
    }

    private final Runnable loop = new Runnable() {
        public void run() {
            paint();
            if (autoShot && System.currentTimeMillis() > busyUntil) fire();
            ui.postDelayed(this, BEAT);
        }
    };

    void fire() {
        if (System.currentTimeMillis() < busyUntil) return;
        int[] s = screen();
        float x1 = aimX(s[0]);
        float y1 = s[1] * GRAB_Y;
        float x2 = x1 + s[0] * ANGLE;
        float y2 = s[1] * RELEASE_Y;

        busyUntil = System.currentTimeMillis() + 1200;
        if (state != null) state.setText("throwing");
        Touch.throwLine(target, x1, y1, x2, y2, ui);
    }

    static final class Line extends View {
        private final BotMenu m;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float x1, y1, x2, y2;
        private boolean on;

        Line(Context c, BotMenu m) {
            super(c);
            this.m = m;
            setClickable(false);
        }

        void show(float a, float b, float c2, float d, boolean visible) {
            x1 = a;
            y1 = b;
            x2 = c2;
            y2 = d;
            on = visible;
            invalidate();
        }

        protected void onDraw(Canvas c) {
            if (!on) return;
            float r = m.dp(16);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(m.dp(3));
            p.setColor(0xFFFF2D95);
            c.drawCircle(x1, y1, r, p);
            p.setStrokeWidth(m.dp(4));
            c.drawLine(x1, y1, x2, y2, p);
            c.drawCircle(x2, y2, m.dp(10), p);
        }
    }
}
