package com.bowlingcrew.mod;

import android.app.Activity;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Hooks every lifecycle entry point and lets BotMenu retry. A single onResume
 * hook was not enough: the decor view is still empty at that point.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TARGET = "com.tetrox.bowl";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (lp.packageName == null || !lp.packageName.startsWith(TARGET)) return;

        hook("onCreate");
        hook("onStart");
        hook("onResume");

        XposedBridge.log("BowlMod: hooked in " + lp.packageName);
    }

    private void hook(String name) {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, name,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            poke(p.thisObject);
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log("hook " + name + " failed: " + t);
        }
    }

    private void poke(Object o) {
        if (!(o instanceof Activity)) return;
        final Activity a = (Activity) o;
        if (!a.getPackageName().startsWith(TARGET)) return;
        try {
            BotMenu.offer(a);
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }
}
