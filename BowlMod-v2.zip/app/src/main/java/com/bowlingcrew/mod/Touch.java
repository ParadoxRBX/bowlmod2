package com.bowlingcrew.mod;

import android.os.Handler;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

/**
 * Pushes a press-and-pull into the game's own view.
 *
 * Same process, same UI thread, real MotionEvents in order, so nothing external
 * can cancel them and there is no system latency.
 */
final class Touch {

    private static final int STEPS = 14;
    private static final long HOLD = 150;
    private static final long DRAG = 220;

    private Touch() {
    }

    static void throwLine(final View target, final float x1, final float y1,
                          final float x2, final float y2, final Handler ui) {

        final long down = SystemClock.uptimeMillis();
        send(target, down, down, MotionEvent.ACTION_DOWN, x1, y1);

        for (int i = 1; i <= STEPS; i++) {
            final float f = i / (float) STEPS;
            final float x = x1 + (x2 - x1) * f;
            final float y = y1 + (y2 - y1) * f;
            final long at = HOLD + (long) (DRAG * f);
            ui.postDelayed(new Runnable() {
                public void run() {
                    send(target, down, down + at, MotionEvent.ACTION_MOVE, x, y);
                }
            }, at);
        }

        ui.postDelayed(new Runnable() {
            public void run() {
                send(target, down, down + HOLD + DRAG,
                        MotionEvent.ACTION_UP, x2, y2);
            }
        }, HOLD + DRAG + 20);
    }

    private static void send(View v, long down, long when, int action, float x, float y) {
        if (v == null) return;
        final MotionEvent e = MotionEvent.obtain(down, when, action, x, y, 0);
        e.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        v.dispatchTouchEvent(e);
        e.recycle();
    }
}
