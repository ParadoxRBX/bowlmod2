# BowlMod 8 — robust attach

Version 7 never drew the dot: the hook fired once on `onResume`, found the decor
view empty, and bailed with no retry. The grab point was also well below the ball.

Fixed:

- Hooks `onCreate`, `onStart` and `onResume`, retries up to 20 times at 250 ms
  until the view tree exists.
- Grab point moved 80% → 66% of height, on the ball.
- Release ends at 30%, above the deck at 27%.
- Toast confirms attach, so silent failure is visible.
- `Touch.java` fix baked in.

## Build

New repo, upload `BowlMod-v2.zip` as one file, commit, paste the workflow from
`BUILD.md`, Run workflow, download `BowlMod-apk`.

## Install

1. Install the new APK; it replaces Bowling Mod 7.
2. LSPatch → Bowling Crew → tick the module again.
3. Launch the game.

A toast reading *mod attached* means the overlay is alive.
